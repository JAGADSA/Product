package com.foods.food.items;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodItemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
